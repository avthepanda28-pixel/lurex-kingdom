LUREX KINGDOM WEBSITE

Upload ALL of these files to the SAME GitHub repository/folder as index.html:

index.html
lurex-kingdom-banner.svg
cheetoz.svg
dominick.svg
skylar.svg
meowly.svg

The Discord invite is already included:
https://discord.gg/T2HymyvKr

The four owner names are:
CHEETOZ
Dominick_2
Skylar
Meowly

IMPORTANT:
The SVG owner images included here are placeholders. Replace each SVG with the actual PFP image if you have one, or change the filenames in index.html to your actual image filenames.
